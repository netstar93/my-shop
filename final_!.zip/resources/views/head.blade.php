<head>
    <script src="{{  asset('/js/lib/jquery-3.3.1.min.js') }}"></script>
    <link href="{{asset('css/app.css')}}" rel="stylesheet" type="text/css" />
{{--    <link href="{{  asset('/css/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />--}}
    <script src="{{  asset('/js/lib/bootstrap.min.js') }}"></script>
    <link href="{{asset('css/style.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />
    <link rel="shortcut icon" href="/images/favicon.ico" />
</head>