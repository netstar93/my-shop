<div class="form-group form-inline">                        
    <label for="uname1">Base Price</label>
    <input type="text" class="form-control form-control-lg" name="base_price" required="true">
    <div class="invalid-feedback">Oops, you missed this one.</div>
</div>
<div class="form-group form-inline">                        
    <label for="uname1">Special Price</label>
    <input type="text" class="form-control form-control-lg" name="special_price" required="">
    <div class="invalid-feedback">Oops, you missed this one.</div>
</div>
                    
