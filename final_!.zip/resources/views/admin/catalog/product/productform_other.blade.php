
<div class="form-group form-inline">                        
    <label for="uname1">Choose attribute(s) for new products  </label>
    <input type="checkbox" class="form-control form-control-lg" name="diff_attr" required=""> Color
    <input type="checkbox" class="form-control form-control-lg" name="diff_attr" required=""> Size
    <div class="invalid-feedback">Oops, you missed this one.</div>
</div>
<div class="form-group">
<table class="table-bordered">
        <tr>
            <td><label for="uname1">Color</label> <input value="red" type="text" name="child_item[0]['color']"  /></td> 
            <td><label for="uname1">Size</label><input value="M" type="text" name="child_item[0]['size']"  /></td>
            <td><label for="uname1">Price</label><input value="299" type="text" name="child_item[0]['price']"  /></td>
        </tr>
        <tr>
            <td><label for="uname1">Color</label> <input value="blue" type="text" name="child_item[1]['color']"  /></td> 
            <td><label for="uname1">Size</label><input value="L" type="text" name="child_item[1]['size']"  /></td>
            <td><label for="uname1">Price</label><input value="290" type="text" name="child_item[1]['price']"  /></td>
        </tr>
</table>
</div>             
