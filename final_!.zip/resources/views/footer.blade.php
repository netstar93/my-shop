<footer>
    <div class="footer">
        <nav class="footer_links">
            <ul>
                <li>
                    <a href="https://scotch.io">Scotch</a>
                    <ul>
                        <li><a href="/about">About</a></li>
                        <li><a href="/authors">Authors</a></li>
                        <li><a href="/contact">Contact</a></li>
                        <li><a href="https://shop.scotch.io">Shop</a></li>
                    </ul>
                </li>
<!--                <li>-->
<!--                    <a href="https://scotch.io">Scotch</a>-->
<!--                    <ul>-->
<!--                        <li><a href="/about">About</a></li>-->
<!--                        <li><a href="/authors">Authors</a></li>-->
<!--                        <li><a href="/contact">Contact</a></li>-->
<!--                        <li><a href="https://shop.scotch.io">Shop</a></li>-->
<!--                    </ul>-->
<!--                </li>-->
                </ul>
        </nav>
     </div>
</footer>