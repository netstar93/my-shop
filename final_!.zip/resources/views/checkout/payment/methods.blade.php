
<div class="payment-method">
    <p>  <input type="radio" value="cod" name="payment-method" id="cod"> Cash On Delivery
    </p>

    <p>
     <input type="radio" value ="paytm-wallet" name="payment-method" id="paytm">  PAYTM
    </p>
</div>
