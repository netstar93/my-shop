@section('title', 'Login')
@extends('admin.layout')
@section('content')
<div class="right-side" >
	<div class="page-content">
		<section class="page-header">
			<h3>Welcome to Dashboard </h3>
		</section>
	</div>
</div>
@endsection